
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<div class="bg-light rounded h-100 p-4">
 <div class="text d-flex justify-content-between">
  <div class="">DANH SÁCH MÃ GIẢM GIÁ </div>
  <div class="adding">
     <a href="/admin/coupon/create"><i class="fa-solid fa-circle-plus fs-3"></i></a>
  </div>
 </div>
  <?php if(Session::has('thongbao')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('thongbao')); ?>

    </div>
  <?php endif; ?>
</a>
  <div class="table-responsive">
      <table class="table table-hover align-middle">
          <thead>
              <tr class="text-dark table-info">
                  <th scope="col">ID</th>
                  <th scope="col">Người gửi</th>
                  <th scope="col">Tiêu đề</th>
                  <th scope="col">Ngày</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $customer_emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                    <td scope="col"><i class="bi bi-envelope"></i></td>
                    <td scope="col"><?php echo e($item->customer_name); ?></td>
                    <td scope="col"><?php echo e($item->subject); ?></td>
                    <td scope="col"><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                    <td>
                        <a href="<?php echo e(route('siteshow-email',['id'=>$item->id])); ?>">Xem</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <nav aria-label="Page navigation example">
        <ul class="pagination">
            <?php echo e($customer_emails->appends(request()->all())->links()); ?>  
        </ul>
      </nav>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>