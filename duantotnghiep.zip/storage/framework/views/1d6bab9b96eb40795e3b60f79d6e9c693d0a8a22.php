<link rel="stylesheet" href="<?php echo e(asset('css/client/component/header.css')); ?>">
<div class="app__header">
        <div class="app__header__control">
           <div class="container">
            <div class="app__logo">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
            </div>
            <div class="action">
                 <form action="<?php echo e(route('clientsearch')); ?>"  class="action-item search">
                    <input type="text" name="q" placeholder="Từ khóa ...">
                    <button type="submit"><i class='bx bx-search'></i></button>
                 </form>
                 <div class="action-item hotline">
                    <i class='bx bx-phone-call bx-tada' ></i>
                    <div class="link">
                         <a href="tel:19008080">
                            <div>Hotline</div>
                            <div>19008080</div>
                         </a>
                    </div>
                 </div>
                 <div class="action-item auth">
                    <i class='bx bx-user'></i>
                    <div class="link">
                        <?php if(auth()->user()): ?>
                        <div><a href="<?php echo e(route('clientaccount')); ?>"><?php echo e(Auth::guard('web')->user()->username); ?></a></div>
                        <?php else: ?>
                        <div><a href="<?php echo e(route('clientshow-register')); ?>">Đăng ký </a></div>
                        <div><a href="<?php echo e(route('clientshow-login')); ?>">Đăng nhập</a></div>
                        <?php endif; ?>
                        
                    </div>
                 </div>
                 <div class="action-item cart position-relative">
                    <a  href="<?php echo e(route('clientcart')); ?>">
                        <i class='bx bx-basket d-flex'></i>
                    </a>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill ">
                        <?php echo e(count($cartFarmApp)); ?>

                      </span>
                 </div>
            </div>
           </div>
        </div>
        <div class="app__header__navigation">
            <div class="container">
                <ul class="menu">
                    <li><a href="<?php echo e(route('clienthome')); ?>">
                        Trang chủ
                    </a></li>
                    <li><a href="">
                        Về chúng tôi
                    </a></li>
                    <li>
                        <a href="<?php echo e(route('clientcategory-group-all')); ?>">
                           Sản phẩm 
                           <i class='bx bxs-down-arrow'></i>
                        </a>
                        <div class="categoryGroupList">
                            <?php $__currentLoopData = $category_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="categoryGroupItem">
                                <div class="title">
                                    
                                    <?php echo e($item->name); ?>

                                </div>
                                <div class="categoryList">
                                    <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                           <a href="<?php echo e(route('clientcategory',["slug"=>$category->slug])); ?>">
                                            <?php echo e($category->category_name); ?>

                                           </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </li>
                    <li><a href="<?php echo e(route('clientnews')); ?>">
                        Tin tức 
                    </a></li>
                    <li><a href="<?php echo e(route('clientaddjobs')); ?>">
                        Tuyển dụng 
                    </a></li>
                    <li><a href="<?php echo e(route('clientshow-contact')); ?>">
                        Liên hệ
                    </a></li>
                    
                </ul>
            </div>
        </div>
</div><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/components/app-header.blade.php ENDPATH**/ ?>