
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/newsDetail.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container mt-4 text-color">
    <div class="row border-bottom">
        <div class="col-lg-3 col-xs-12">
            <div class="aside-content">
                <h2 class="title-head">
                    Danh mục tin
                </h2>
                <nav class="nav-category navbar-toggleable-md pb-3">
                    <ul class="nav flex-column">
                        <?php $__currentLoopData = $category_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item position-relative p-8">
                            <a href=""><?php echo e($item->name); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </nav>
            </div>
            <div class="aside-content">
                <h2 class="title-head">
                    Có thể bạn quan tâm
                </h2>
                <div class="list-blogs ">
                    <?php $__currentLoopData = $newsRelate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412 = $component; } ?>
<?php $component = App\View\Components\NewsCard::resolve(['isRow' => ''.e(true).'','link' => ''.e(route('clientnews-detail',['slug'=>$item->slug])).'','title' => ''.e($item->title).'','thumb' => ''.e($item->thumb).'','summary' => ''.e($item->summary).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('NewsCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NewsCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412)): ?>
<?php $component = $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412; ?>
<?php unset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <article class="col-lg-9 col-xs-12">
            <h1 class="article-name font-weight-bold"><?php echo e($post->title); ?></h1>
            <div class="entry-date">
                <p>Đăng bởi: <b><?php echo e($post->created_by); ?> - <?php echo e($post->created_at->format('d/m/Y')); ?></b></p>
            </div>
            <div class="table-of-contents">
                <?php echo $post->content; ?>

            </div>
        </article>
    </div>
    <div class="row mb-5">
        <div class="col-6 ">
            <h3 class="title">Viết bình luận</h3>
            <form method="POST" action="<?php echo e(route('clientcomment')); ?>" id="article_comments" accept-charset="UTF-8" class="comment-form">
                <?php echo csrf_field(); ?>
                <?php if(Auth::guard('web')->check()==false): ?>
                <p class="alert alert-warning">
                    Vui lòng đăng nhập để thực hiện chức năng bình luận
                </p>
                <?php endif; ?>
                <input type="text" name="user_id" value="<?php echo e(Auth::guard('web')->user()->id??null); ?>" hidden>
                <input type="text" name="news_id" value="<?php echo e($post->id); ?>" hidden>
                
                <div class="field aw-blog-comment-area form-group">
                    <textarea rows="6" cols="50" class="form-control" title="Nội dung *" placeholder="Nội dung*"
                        name="content"></textarea>
                    <span class="text-danger"><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>
                <div style="width:96%" class="button-set">
                    <button type="submit"
                        class="book-submit btn btn-primary text-center d-flex align-items-center font-weight-boldt font-weight-bold"
                        <?php if(Auth::guard('web')->check()==true?false:true): echo 'disabled'; endif; ?> >Gửi
                        bình luận
                    </button>
                </div>
            </form>
        </div>
        <div class="col-6">
            <h3 class="title">Bình luận</h3>
            <?php if(count($comments)>0): ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="comment-container">
                <div class="comment-header">
                    <img src="https://via.placeholder.com/40x40" alt="Avatar">
                    <h4><?php echo e($item->author->username); ?></h4>
                </div>
                <div class="comment-body">
                    <p><?php echo e($item->content); ?></p>
                </div>
                <div class="comment-footer">
                    <span>Thích</span>
                    <span>Trả lời</span>
                    <span><?php echo e($item->created_at->format('d/m/Y')); ?></span>
                    <a href="#">Xóa</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="alert alert-warning">
                Hiện tại chưa có bình luận.
            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <h3 class="title">Bài viết liên quan</h3>
        <div class="col-12">
            <div style="display: grid;grid-template-columns:repeat(4,1fr);gap :10px;margin-top: 20px;">
  
              <?php $__currentLoopData = $newsRelate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if (isset($component)) { $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412 = $component; } ?>
<?php $component = App\View\Components\NewsCard::resolve(['isRow' => ''.e(false).'','link' => ''.e(route('clientnews-detail',['slug'=>$item->slug])).'','title' => ''.e($item->title).'','thumb' => ''.e($item->thumb).'','summary' => ''.e($item->summary).'','day' => ''.e($item->created_at->format('d')).'','month' => ''.e($item->created_at->format('m/Y')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('NewsCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NewsCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412)): ?>
<?php $component = $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412; ?>
<?php unset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/newsDetail/index.blade.php ENDPATH**/ ?>