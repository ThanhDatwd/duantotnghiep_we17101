

<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <div class="text-start">
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
               <div>Lịch sử nhập hàng</div>
               <div class="adding">
                <a href="admin/news/them"><i class="fa-solid fa-circle-plus fs-3"></i></a>
             </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead >
                            <tr class="text-dark table-info">
                                <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                <th scope="col">Mã phiếu</th>
                                <th scope="col">Ngày nhập</th>
                                <th scope="col">Người nhập</th>
                                <th scope="col">Nhà cung cấp</th>
                                <th scope="col" class="text-center">Trạng thái</th>
                                <th scope="col">Tổng</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchase_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input class="form-check-input" type="checkbox"></td>
                                <td><?php echo e($item->purchase_code); ?></td>
                                <td> <?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                <td><?php echo e($item->created_by!=null?$item->created_by:"Admin"); ?></td>
                                <td><?php echo e($item->brand!=null?$item->brand:"(Không nhập)"); ?></td>
                                <td class="text-center">
                                    <?php if($item->purchase_status==true): ?>
                                    <button class="btn btn-sm btn-success rounded-pill">Hoàn thành</button>
                                    <?php else: ?>
                                       <button class="btn btn-sm btn-secondary rounded-pill">Lưu tạm</button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e(number_format($item->total_cost)); ?> VNĐ
                                </td>
                                <td>
                                    <a href="<?php echo e(route('siteshow-purchase-history-detail',['id'=>$item->id])); ?>">Xem</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/purchase/history.blade.php ENDPATH**/ ?>