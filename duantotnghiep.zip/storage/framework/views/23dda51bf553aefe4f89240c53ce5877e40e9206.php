
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;
?>
<form action="<?php echo e(url('admin/admin_users/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

                   <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Quản lý Admin</h6>
                            <div class="table-responsive">
                       <table class="table">
                     <thead>
                     <tr>
                  <th></th>
                                         <th scope="col"></th>
                                            <th scope="col">Hình đại diện</th>
                                            <th scope="col">Tên Admin</th>

                                            <th scope="col">Tài khoản</th>
                                            <th scope="col">Email</th>
                                          <th scope="col">Số điện thoại</th> 
                                            <th scope="col"></th>
                                            
                                            
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <td><input type="checkbox" name="check[]" value="<?php echo e($item->id); ?>"></td>
                  <td><img src="<?php echo e(asset('upload/'.$item->avatar)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" style="width: 100px;height: 100px;"></td>
                  </td>
           
                                    
                                        <td><?php echo e($item->username); ?></td>
                                        <td><?php echo e($item->full_name); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->phone); ?></td>
                                    
                                    
                                       
                                       
                                         <td colspan="">
                                            <a href="<?php echo e(url('admin/admin_users/capnhat/'.$item->id)); ?>" class="btn btn-primary">Sửa</a>
                                            <a href="<?php echo e(url('admin/admin_users/xoa/'.$item->id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa không?')" class="btn btn-danger">Xóa</a>
                                             
                                        </td>
                                        
                                      
                                    </tr>
                                    <tr>
                                       
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                     

                
                
                  
                  
                  <td class="button">
                    
                   
                

                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
        </script>
        </td>

        </tr>

        </tbody>


              </tr>
          </tbody>
        
          
      </table>



      <nav aria-label="Page navigation example">
        <ul class="pagination" style="display: flex;justify-content:space-between;">

          <li> <?php echo e($users->appends(request()->all())->links()); ?> </li>

          <li>
            <a href="<?php echo e(url('admin/admin_users/them')); ?>" class="btn btn-primary">Thêm</a>

            <a href="<?php echo e(url('admin/admin_users/thung-rac')); ?>" class="btn btn-primary">Thùng rác
              <?php
                                                $count = DB::table('administrators')->where('deleted_at','!=',null)->count();
                                                ?>
              (<?php echo e($count); ?>)

            </a>
            <button type="submit" class="btn btn-danger">Xóa nhiều</button>
          </li>


        </ul>
      </nav>
    </div>
  </div>



</form>

<?php $__env->stopSection(); ?>

</form>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/admin_users/index.blade.php ENDPATH**/ ?>