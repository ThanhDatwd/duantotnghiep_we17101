
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">
 <style>
     .td-banner{
        position: relative;
        height: 240px;
        border: 2px dashed #0f9249;
     }
     .td-banner img{
        position: absolute;
        width: 100%
     }
     .td-banner .icon{
         display: inline;
         position: absolute;
         top: 16px;
         right: 16px;
     }
     .td-banner .icon i{
      font-size: 22px
     }
 </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;
?>
<form action="<?php echo e(url('admin/banner/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="p-4">
    <?php if(Session::has('thongbao')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('thongbao')); ?>

    </div>
    <?php endif; ?>
    <div class="text-start">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <div>Banner</div>
          <div class="adding">
            <a href="/admin/banner/them"><i class="fa-solid fa-circle-plus fs-3"></i></a>
          </div>
        </div>
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-hover align-start">
              <thead class="text-dark table-info">
                <tr>
                  <th scope="col">Hình ảnh</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td >
                    <div class="position-relative td-banner" style=" height:240px">
                      <img  src="<?php echo e(asset('upload/'.$item->url)); ?>" alt=""
                        onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" class="position-absolute w-100 h-100 t-0 l-0">
                        <div class="icon">
                          <a style="color: red" href="<?php echo e(url('admin/banner/xoa/'.$item->id)); ?>" onclick="return myFunction();">
                            <i class="bi bi-trash"></i> </a>
                        </div>

                    </div>
                  </td>
                  <script>
                    function myFunction() {
                        if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                        event.preventDefault();
                    }
                  </script>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/banner/index.blade.php ENDPATH**/ ?>