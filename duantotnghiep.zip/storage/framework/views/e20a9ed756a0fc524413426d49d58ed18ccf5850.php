
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .text h2{
        margin: auto;
        text-align: center;
    }
</style>

<form action="/admin/coupon/create" enctype="multipart/form-data" method="post">
    <?php echo csrf_field(); ?>
    <div class="adproduct">
<div class="text">

    <h2 >THÊM MÃ GIẢM GIÁ</h2>
</div>
        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class= "container-fluid col-12 m-auto coupou">
            <div class= "row">
               <div class ="col-md-12 col-sm-6 ">
                <div class="boxlist1">
                    <div class="addpro">
                        <div class="adpro1">
                            <p>Mã giảm giá<span>(*)</span></p>
                            <input type="text" name="coupon_code" value="<?php echo e(old('coupon_code')); ?>" placeholder="   Nhập mã giảm giá">
                            <?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Loại giảm giá <span>(*)</span></p>
                            <select name="coupon_type">
                                <option value="1">Giảm giá theo %</option>
                                <option value="2">Giảm giá theo số tiền</option>
                                <option value="3">Giảm giá theo đơn hàng</option>
                            </select>
                        </div>
                    </div>
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Nhập số % hoặc tiền giảm <span>(*)</span></p>
                            <input type="number" name="discount" value="<?php echo e(old('discount')); ?>" placeholder="Nhập nguồn hàng">
                            <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        
                    </div>
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Điều kiện sử dụng<span>(*)</span></p>
                            <input type="number" name="min_condition" value="<?php echo e(old('min_condition')); ?>" placeholder="Nhập số lượng mã">
                            <?php $__errorArgs = ['min_condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        
                    </div>
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Giới hạn người sử dụng</p>
                            <input type="number" name="limit_used" value="<?php echo e(old('limit_used')); ?>" placeholder="Nhập giới hạn người dùng">
                            <?php $__errorArgs = ['limit_used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        
                    </div>
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Trang thái<span>(*)</span></p>
                            <select name="is_active" id="">
                                <option value="1">Hoạt động</option>
                                <option value="0">Ẩn</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Ngày bắt đầu</p>
                            <input type="datetime-local" value="<?php echo e(old('start_date')); ?>" name="start_date" >
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="adpro1">
                            <p>Ngày kết thúc</p>
                            <input type="datetime-local" value="<?php echo e(old('end_date')); ?>" name="end_date" >
                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        
                    </div>
            
                    <div class="addpro">    
                        <div class="adpro1">
                            <p>Miêu tả  <span>(*)</span></p>
                            <textarea name="description" id="" value="<?php echo e(old('address')); ?>" cols="100" class="texlo" rows="5"></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="badge badge-danger"><?php echo e($message); ?></span>                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    
                </div>
                
               </div>
         
        
    </div>
    <div class="ci"><button type="submit" class="btnmoi">Thêm mới</button>
        <a href="/admin/coupon">Hủy</a>
    </div>
               </div>
            </div>
         </div>
        
        </div>
                  
        
    
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/coupon/create.blade.php ENDPATH**/ ?>