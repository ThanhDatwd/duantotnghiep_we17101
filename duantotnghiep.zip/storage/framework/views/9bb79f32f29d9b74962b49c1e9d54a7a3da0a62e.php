
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="p-4">
  <?php if(Session::has('thongbao')): ?>
  <div class="alert alert-success">
    <?php echo e(Session::get('thongbao')); ?>

  </div>
  <?php endif; ?>
  <div class="text-start">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <div>Danh sách nhóm loại sản phẩm</div>
        <div class="adding">
          <a href="/admin/category_group/create"><i class="fa-solid fa-circle-plus fs-3"></i></a>
        </div>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle">
          <thead class="text-dark table-info">
              <tr>
                  <th></th>
                  <th scope="col">ID</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Danh mục</th>
             
                  <th scope="col">Trạng thái</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $categroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <th><?php echo e($c->id); ?></th>
                  <td><img style="width:50px; height:50px"  src="<?php echo e(asset('upload/'.$c->thumb)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" >
                  </td>
                  <td>
                    <p style="font-size: 18px; font-weight:bold"><?php echo e($c->name); ?></p>
                  </td>
                 <td>
                    <span>
                      <?php if(($c->is_active)==1): ?>
                      <button type="button" class="btn btn-success">Hiện</button>
                      <?php else: ?>
                      <button type="button" class="btn btn-danger">Ẩn</button>                  
                    <?php endif; ?>
                    </span>
                  </td>
                  
                  <td class="">
                    <a style="color: cadetblue" href="/admin/category_group/update/<?php echo e($c->id); ?>"><i  class="bi bi-pencil-square"></i></a>
                    <a style="color: red" href="/admin/category_group/delete/<?php echo e($c->id); ?>" onclick="return myFunction();"> <i onclick="myFunction()"  class="bi bi-trash"></i> </a>
                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
                     </script>
                  </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>
  </div>
</div>
</div>
<div class="mt-2">
<nav aria-label="Page navigation example ">
  <ul class="pagination">
    <?php echo e($categroup->appends(request()->all())->links()); ?>  
  </ul>
</nav>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/category_group/index.blade.php ENDPATH**/ ?>