
<?php $__env->startSection('css'); ?>
<title>Cảm ơn bạn đã mua hàng!</title>
<link rel="stylesheet" href="<?php echo e(asset('css/client/thankyou.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
  <div class="container">
    <header>
      <div class="logo">
        <img style="width:160px" src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
      </div>
      <h1>Cảm ơn bạn đã mua hàng!</h1>
    </header>
    <div class="customer-info">
      <div class="confirm-info">
        <div class="confirm-line">
            <h3>Thông tin mua hàng</h3>
            <p><strong>Tên khách hàng :</strong><?php echo e($order->user_name); ?></p>
            <p><strong>Số điện thoại  :</strong><?php echo e($order->phone); ?></p>
            <p><strong>Email          :</strong><?php echo e($order->email); ?></p>
        </div>
         <div class="confirm-line">
            <h3>Đia chỉ giao hàng</h3>
            <p><strong>Địa chỉ nhà   :</strong><?php echo e($order->address); ?></p>
            <p><strong>Khu vực  :</strong><?php echo e($order->ward); ?>, <?php echo e($order->district); ?>, <?php echo e($order->province); ?></p>
        </div>
         <div class="confirm-line">
            <h3>Phương thức giao dịch</h3>
            <?php if($order->payment_type=='ATM'): ?>
              <p class="email">Thanh toán online</p>
              
            <?php else: ?>
            <p class="email">Thanh toán khi nhận hàng</p>
              
            <?php endif; ?>
        </div>
         <div class="confirm-line">
            <h3>Phương thức vận chuyển</h3>
            <p class="name">Giao Tận nơi</p>
        </div>
    </div>
    </div>
    
    <div class="order-details">
      <!-- Hiển thị danh sách sản phẩm ở đây -->
      <div class="confirm-orderList">
        <h4>Đơn hàng <span class="id-order"><?php echo e($order->code); ?></h4>
        <ul class="order-list">
          <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="order-item">
            <div class="order-item_img">
                <img src="<?php echo e(asset('upload/'.$item->product_thumb)); ?>" alt="">
                <span><?php echo e($item->quantity); ?></span>
            </div>
            <div class="order-item_txt">
                <div>
                    <p class="name"><?php echo e($item->product_name); ?></p>
                </div>
                <div class="price"><?php echo e(number_format($item->price)); ?></div>
            </div>
        </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </ul>
        <div class="orderSumary">
          <div class="orderSumary-line total">
            <span class="text">Tổng cộng</span>
            <span class="price">
               <?php echo e(number_format($order->total)); ?>

            </span>
          </div>
        </div>
      </div>
    
      <div class="thank-you">
        <h2>Cảm ơn bạn đã mua hàng!</h2>
        <p>Xin vui lòng giữ đơn hàng của bạn cho tới khi bạn nhận được sản phẩm của mình.</p>
        <div class="d-flex  align-items-center justify-content-between">
          <a href="<?php echo e(route('client')); ?>">Trở về trang mua hàng</a>
          <button class="btn btn-primary" onclick="window.print()">In đơn hàng</button>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.appLayoutEmpty.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/thankyou/index.blade.php ENDPATH**/ ?>