<link rel="stylesheet" href="<?php echo e(asset('css/client/component/newsCard.css')); ?>">
<a href="<?php echo e($link); ?>" class="news-card <?php echo e($isRow==true?'isRow':''); ?>">
    <div class="thumb">
        <img src=<?php echo e(asset('upload/'.$thumb)); ?> alt="">
        <div class="thumb-layer">
            <img class="thumb-layer-img" src="https://bizweb.dktcdn.net/100/434/011/themes/845632/assets/favicon.png?1667206835361" alt="">
        </div>
        <div class="date">
            <div>
                <div class="day"><?php echo e($day); ?></div>
                <div class="month"><?php echo e($month); ?></div>
            </div>
        </div>
    </div>
    <div class="content">
        <h3 class="title"><?php echo e($title??null); ?></h3>
         <div class="summary">
            <?php echo e($summary??null); ?>

        </div>
    </div>
</a>




<?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/components/news-card.blade.php ENDPATH**/ ?>