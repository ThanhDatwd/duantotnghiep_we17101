
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/login.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="auth-form__container">
        <div class="auth-form">
            <div class="auth-form__head">
                <a href="<?php echo e(route('clientshow-login')); ?>">
                    <li class="auth-form__heading">Đăng nhập</li>
                </a>
                <a href="">
                    <li class="auth-form__heading active">Đăng kí</li>
                </a>
            </div>
            <form action="<?php echo e(route('clientregister')); ?>" method="POST" class="auth-form__register">
                <?php echo csrf_field(); ?>
                <div class="auth-form__group">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('fail')): ?>
                    <div class="mesage"><?php echo e(Session::get('fail')); ?></div>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                    <?php endif; ?>

                </div>
                <!-- Đây là chỗ đăng nhập -->
                <div class="auth-form__group">
                    <div class="auth-form__group-data">
                        <label class="group-label">họ tên</label>
                        <span class="group-obli">*</span>
                    </div>
                    <input type="text" name="username" value="<?php echo e(old("username")); ?>" placeholder="Nhập Họ" />
                    <span class="text-danger"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
                <div class="auth-form__group">
                    <div class="auth-form__group-data">
                        <label class="group-label">số điện thoại</label>
                        <span class="group-obli">*</span>
                    </div>
                    <input type="number" name="phone" value="<?php echo e(old("phone")); ?>" placeholder="Nhập Số Điện Thoại" />
                    <span class="text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
                <div class="auth-form__group">
                    <div class="auth-form__group-data">
                        <label class="group-label">email</label>
                        <span class="group-obli">*</span>
                    </div>
                    <input type="email" name="email" value="<?php echo e(old("email")); ?>" placeholder="Nhập Địa Chỉ Email" require />
                    <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
                <div class="auth-form__group">
                    <div class="auth-form__group-data">
                        <label class="group-label">mật khẩu</label>
                        <span class="group-obli">*</span>
                    </div>
                    <input type="password" name="password" placeholder="Nhập Mật Khẩu" />
                    <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
                <button class="auth-form__btn" type="submit">
                    TẠO TÀI KHOẢN
                </button>
            </form>
            <div class="register-form"></div>
        </div>
        <div class="auth-form__aside">
            <p class="auth-form__or">Hoặc đăng nhập qua</p>
        </div>
        <div class="auth-form__logins">
            <a href="#" class="logins-facebook login">
                <ion-icon name="logo-facebook"></ion-icon>
                <span>Facebook</span>
            </a>
            <a href="#" class="logins-google login">
                <ion-icon name="logo-google"></ion-icon>
                <span>Google</span>
            </a>
        </div>
    </div>
</main>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/register/index.blade.php ENDPATH**/ ?>