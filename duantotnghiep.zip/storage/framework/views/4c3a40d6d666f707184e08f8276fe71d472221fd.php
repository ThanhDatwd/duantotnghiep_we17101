
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="bg-light rounded h-100 p-4">
 <div class="text">
  <h2 class="">THÙNG RÁC NGUỒN HÀNG </h2>

  <a href="/admin/brand/create"><i class="fa-solid fa-circle-plus"></i> Thêm nguồn hàng</a>
 </div>
  <?php if(Session::has('thongbao')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('thongbao')); ?>

    </div>
  <?php endif; ?>
</a>
</a>
<div class="table-responsive">
  <a href="restore-all"  ><button type="button" class="btn btn-success m-2"><i class="fa fa-home me-2"></i>Khôi Phục Tất Cả</button>

      <table class="table">
          <thead>
              <tr>
                  <th></th>
                  <th scope="col">ID</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Nơi nhập hàng</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <th><?php echo e($b->id); ?></th>
                  <td><img src="<?php echo e(asset('upload/'.$b->avatar)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" >
                  </td>
                  

                  <td><?php echo e($b->brands); ?></td>
                  <td class="button">
                    <a style="color: cadetblue" href="/admin/brand/restore/<?php echo e($b->id); ?>"><i class="fa-solid fa-trash-arrow-up"></i></a>
                    <a style="color: red" href="/admin/brand/trashed/forceDelete/<?php echo e($b->id); ?>" onclick="return myFunction();"> <i onclick="myFunction()" class="fa-sharp fa-solid fa-trash"></i> </a>
                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
                     </script>
                  </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/brand/trashed.blade.php ENDPATH**/ ?>