
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/search.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container search-page mt-4">
  <h3>tìm thấy <strong></strong> <?php echo e(count($products)); ?> kết quả cho <strong>" <?php echo e($q); ?> "</strong></h3>
  <div class="row mt-4">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $price1="";
    $price2=number_format($item->price_current);
    if($item->discount>0){
    $price1=number_format($item->price_current)."đ";
    $price2=number_format($item->price_current-($item->price_current*$item->discount/100));
    }
    ?>
    <div class="col-3">
      <?php if (isset($component)) { $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5 = $component; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['link' => ''.e(route('clientproduct-detail',['slug'=>$item->slug])).'','name' => ''.e($item->name).'','thumb' => ''.e($item->thumb).'','priceOld' => ''.e($price1).'','priceCurrent' => ''.e($price2).'đ','discount' => ''.e($item->discount).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ProductCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5)): ?>
<?php $component = $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5; ?>
<?php unset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5); ?>
<?php endif; ?>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/search/index.blade.php ENDPATH**/ ?>