
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/cart.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container ">
    <nav aria-label="breadcrumb  " style="<?php echo \Illuminate\Support\Arr::toCssStyles("border-bottom:1px solid red; ") ?>">
        <ol class="breadcrumb p-3" style="<?php echo \Illuminate\Support\Arr::toCssStyles("margin:0;padding-left:0px") ?>">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="#">Library</a></li>
          <li class="breadcrumb-item active" aria-current="page">Data</li>
        </ol>
      </nav>
<?php if(count($carts)>0): ?>
   <div class="row">
       <div class="col-12 col-md-8 mt-2 mb-2">
        <div class="cart-items">
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cart-item">
                <img class="item-img" src="<?php echo e($item->thumb); ?>" alt="">
                <div class="cart-info">
                    <div class="info">
                        <div class="item-name"><?php echo e($item->name); ?></div>
                        <div class="item-price">
                            <?php echo e(number_format($item->price_current-($item->price_current*$item->discount/100))); ?></div>
                    </div>
                    <div class="info">
                        <div class="btn-quantity">
                            <form action="<?php echo e(route('clientminus-to-cart')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                               <input type="text" name="productId" value="<?php echo e($item->id); ?>" hidden>
                               <input type="number" name="amount" value="1" hidden>
                                <button class="minus">-</button>
                            </form>
                            <span class="count"><?php echo e($item->amount); ?></span>
                            <form action="<?php echo e(route('clientadd-to-cart')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                               <input type="text" name="productId" value="<?php echo e($item->id); ?>" hidden>
                               <input type="number" name="amount" value="1" hidden>
                                <button class="plus">+</button>
                            </form>
                        </div>
                        <form action="<?php echo e(route('clientremove-to-cart')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="productId" value="<?php echo e($item->id); ?>" hidden>
                            <button class="btn btn-delete">Xóa</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       </div>
       <div class="col-12 col-md-4 mt-2 mb-2">
        <div class="checkout">
            <div class="btn checkout-info">
                <div class="total-text">Tổng</div>
                <div class="total-value"><?php echo e(number_format($total)); ?> vnđ</div>
            </div>
            <a href="<?php echo e(route('clientpayment')); ?>" class="btn btn-ok">Thanh toán</a>
            <form action="<?php echo e(route('clientremove-all-cart')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button style="width:100%" class="btn btn-delete-all">Xóa tất cả</button>
            </form>
        </div>
       </div>
   </div>
    <?php else: ?>
    <div class="alert alert-warning ">Không có sản phẩm nào. Quay lại <b> <a href="<?php echo e(route('clientcategory-group-all')); ?>"> cửa hàng </a> </b> để tiếp tục mua sắm.</div>
    <?php endif; ?>
</div>

<div class="container">
    <?php if(count(json_decode($coupons))>0): ?>
<?php if (isset($component)) { $__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14 = $component; } ?>
<?php $component = App\View\Components\CouponCard::resolve(['list' => $coupons] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('AppCouponCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CouponCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14)): ?>
<?php $component = $__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14; ?>
<?php unset($__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14); ?>
<?php endif; ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script>
    let minusBtn = document.querySelector(".minus");
        let count = document.querySelector(".count");
        let plusBtn = document.querySelector(".plus");

        let countNum = 1;
        count.value = countNum;

        minusBtn.addEventListener("click", () => {
            countNum -= 1;
            count.value = countNum;
        });

        plusBtn.addEventListener("click", () => {
            countNum += 1;
            count.value = countNum;
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/cart/index.blade.php ENDPATH**/ ?>