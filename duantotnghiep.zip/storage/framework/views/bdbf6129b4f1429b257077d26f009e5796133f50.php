
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/home.css')); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?php echo e(asset('css/client/product.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />


<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<section  class="container">
    <nav aria-label="breadcrumb  " style="<?php echo \Illuminate\Support\Arr::toCssStyles("border-bottom:1px solid #eae8e8; ") ?>">
      <ol class="breadcrumb p-3" style="<?php echo \Illuminate\Support\Arr::toCssStyles("margin:0;padding-left:0px") ?>">
        <li class="breadcrumb-item"><a href="<?php echo e(route('client')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
      </ol>
    </nav>
  </section>
<div class="container">
    <div class="products">
        <h1><?php echo e($title); ?></h1>
        <div class="image-slider">
            <div class="image-item">
                <div class="image">
                    <img src="https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/AN_images/healthy-eating-ingredients-1296x728-header.jpg?w=1155&h=1528"
                        alt="">
                </div>
            </div>
            <div class="image-item">
                <div class="image">
                    <img src="https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/AN_images/healthy-eating-ingredients-1296x728-header.jpg?w=1155&h=1528"
                        alt="">
                </div>
            </div>
            <div class="image-item">
                <div class="image">
                    <img src="https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/AN_images/healthy-eating-ingredients-1296x728-header.jpg?w=1155&h=1528"
                        alt="">
                </div>
            </div>
            <div class="image-item">
                <div class="image">
                    <img src="https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/AN_images/healthy-eating-ingredients-1296x728-header.jpg?w=1155&h=1528"
                        alt="">
                </div>
            </div>
            <div class="image-item">
                <div class="image">
                    <img src="https://images.immediate.co.uk/production/volatile/sites/30/2020/08/processed-food700-350-e6d0f0f.jpg"
                        alt="">
                </div>
            </div>

        </div>


        
        <div class="row">
            <div class="col-12 col-lg-3 d-sm-block d-none"  >
                <div class="pro-1">
                    <div class="customsselects">
                        <div class="s1">
                            <h2>DANH MỤC</h2>
                            <?php $__currentLoopData = $categoryGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="select">
                                
                                <div class="select-title">
                                    <a href="<?php echo e(route('clientcategory-group',["slug"=>$group->slug])); ?>"><?php echo e($group->name); ?></a>
                                    <i class='bx bxs-down-arrow'></i>
                                </div>
                                <ul>
                                    <?php $__currentLoopData = $group->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="select-option"><a href="<?php echo e(route('clientcategory',["slug"=>$item->slug])); ?>"><?php echo e($item->category_name); ?></a></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                        </div>

                    </div>
                </div>
                <div class="pro-1">
                    <form class="pro-text">
                        <p>Thương hiệu</p>
                          <input type="checkbox" id="html" name="fav_language" value="HTML">
                          <label for="html">HTML</label><br>
                          <input type="checkbox" id="css" name="fav_language" value="CSS">
                          <label for="css">CSS</label><br>
                          <input type="checkbox" id="javascript" name="fav_language" value="JavaScript">
                          <label for="javascript">JavaScript</label>

                        <br> <br>

                        <p>Loại</p>
                          <input type="checkbox" id="html" name="fav_language" value="HTML">
                          <label for="html">HTML</label><br>
                          <input type="checkbox" id="css" name="fav_language" value="CSS">
                          <label for="css">CSS</label><br>
                          <input type="checkbox" id="javascript" name="fav_language" value="JavaScript">
                          <label for="javascript">JavaScript</label>
                    </form>
                </div><br>
                
                <div class="pro-1">
                    <h2>MẸO ĂN NGON</h2>
                    <div class="pro-new">
                        <?php if (isset($component)) { $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412 = $component; } ?>
<?php $component = App\View\Components\NewsCard::resolve(['isRow' => 'true','title' => 'tiêu đề bài viết','thumb' => 'https://static-images.vnncdn.net/files/publish/2022/12/2/bo-kobe-1052.gif','summary' => ' Lợi ích của cá hồi trong bữa cơm gia đình hàng ngày So với nhiều mặt hàng thực phẩm tươi '] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('NewsCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NewsCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412)): ?>
<?php $component = $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412; ?>
<?php unset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412); ?>
<?php endif; ?>
                    </div>

                </div>
            </div>
            
            <div class="col-12 col-lg-9">

                <div class="pro-xep">
                    <div class="pro-x">
                        <p style="float: left">Sắp xếp:</p>

                        <form class="pro-text" style="float: left">
                              <input type="radio" id="" name="fav_language" value="">
                              <label for="">A-Z</label>
                              <input type="radio" id="" name="fav_language" value="">
                              <label for="">Z-A</label>
                              <input type="radio" id="" name="fav_language" value="">
                              <label for="">Gía tăng dần</label>
                              <input type="radio" id="" name="fav_language" value="">
                              <label for="">Giá giảm dần</label>
                              <input type="radio" id="" name="fav_language" value="">
                              <label for="">Mới nhất</label>
                              <input type="radio" id="" name="fav_language" value="">
                              <label for="">Cũ nhất</label>
                        </form>
                    </div>
                </div>

                <?php if(count($products)>0): ?>
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $price1="";
                    $price2=number_format($item->price_current);
                    if($item->discount>0){
                    $price1=number_format($item->price_current)."đ";
                    $price2=number_format($item->price_current-($item->price_current*$item->discount/100));
                    }
                    ?>
                    <div class="col-6  col-lg-3 mb-2 mt-2">
                        <?php if (isset($component)) { $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5 = $component; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['link' => ''.e(route('clientproduct-detail',['slug'=>$item->slug])).'','name' => ''.e($item->name).'','thumb' => ''.e($item->thumb).'','priceOld' => ''.e($price1).'','priceCurrent' => ''.e($price2).'đ','discount' => ''.e($item->discount).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ProductCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5)): ?>
<?php $component = $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5; ?>
<?php unset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5); ?>
<?php endif; ?>
    
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <div class="alert alert-warning d-flex justify-content-center">Danh mục trống</div>

                <?php endif; ?>

                <div class="d-flex justify-content-center mt-3"><?php echo e($products->appends(request()->all())->links()); ?></div>

            </div>

        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>



<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="<?php echo e(asset('./js/client/product.js')); ?>"></script>




<script src="<?php echo e(asset('js/client/product.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/products/index.blade.php ENDPATH**/ ?>