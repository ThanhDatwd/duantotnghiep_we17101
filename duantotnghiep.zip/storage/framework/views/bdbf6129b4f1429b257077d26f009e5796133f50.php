
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/home.css')); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?php echo e(asset('css/client/product.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />


<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<section class="container">
    <nav aria-label="breadcrumb  " style="<?php echo \Illuminate\Support\Arr::toCssStyles("border-bottom:1px solid #eae8e8; ") ?>">
      <ol class=" breadcrumb p-3" style="<?php echo \Illuminate\Support\Arr::toCssStyles("margin:0;padding-left:0px") ?>">
        <li class="breadcrumb-item"><a href="<?php echo e(route('client')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
        </ol>
    </nav>
</section>
<div class="container">
    <div class="products">
        <h1><?php echo e($title); ?></h1>
        <div class="swiper mySwiperService">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                  <img style="width:100%"
                    src="https://bizweb.dktcdn.net/100/434/011/themes/845632/assets/banner_collec_1.jpg?1681360920404"
                    alt="">
              </div>
              <div class="swiper-slide">
                  <img style="width:100%"
                    src="https://bizweb.dktcdn.net/100/434/011/themes/845632/assets/banner_collec_2.jpg?1681360920404"
                    alt="">
              </div>
              
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
          </div>
        
        <div class="row">
            <div class="col-12 col-lg-3 d-sm-block d-none">
                <div class="pro-1">
                    <div class="customsselects">
                        <div class="s1">
                            <h2>DANH MỤC</h2>
                            <?php $__currentLoopData = $categoryGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="select">
                                
                                <div class="select-title">
                                    <a href="<?php echo e(route('clientcategory-group',["slug"=>$group->slug])); ?>"><?php echo e($group->name); ?></a>
                                    <i class='bx bxs-down-arrow'></i>
                                </div>
                                <ul>
                                    <?php $__currentLoopData = $group->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="select-option"><a href="<?php echo e(route('clientcategory',["slug"=>$item->slug])); ?>"><?php echo e($item->category_name); ?></a></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                        </div>

                    </div>
                </div>
                <div class="pro-1">
                    <form class="pro-text">
                            <aside class="aside-item filter-price mb-3 col-12 col-sm-12 col-lg-12">
                                <div class="h2 title-head m-0 pt-2 pb-2 font-weight-bold">Lọc giá</div>
                                <div class="aside-content filter-group mb-1">
                                    <div class="row">
                                        <div class="col-6 col-lg-12 col-xl-6">
                                            <label class="d-flex align-items-baseline pt-1 pb-1 m-0"
                                                for="filter-khoanggia-tu">
                                                <input type="text" id="filter-khoanggia-tu" name="min_price" class="form-control" value="<?php echo e(old("min_price")); ?>"
                                                    placeholder="Giá tối thiểu ">
                                            </label>
                                        </div>
                                        <div class="col-6 col-lg-12 col-xl-6">
                                            <label class="d-flex align-items-baseline pt-1 pb-1 m-0"
                                                for="filter-khoanggia-den">
                                                <input type="text" id="filter-khoanggia-den" name="max_price" class="form-control" value="<?php echo e(old("max_price")); ?>"
                                                    placeholder=" Giá tối đa ">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-primary js-filter-pricerange font-weight-bold" href="javascript:;"
                                    data-value="(>=1000 AND <=1100000)">Áp dụng</button>
                            </aside>
                    </form>
                </div><br>
                
                <div class="pro-1">
                    <h2>MẸO ĂN NGON</h2>
                    <div class="pro-new">
                        <?php if (isset($component)) { $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412 = $component; } ?>
<?php $component = App\View\Components\NewsCard::resolve(['isRow' => 'true','title' => 'tiêu đề bài viết','thumb' => 'https://static-images.vnncdn.net/files/publish/2022/12/2/bo-kobe-1052.gif','summary' => ' Lợi ích của cá hồi trong bữa cơm gia đình hàng ngày So với nhiều mặt hàng thực phẩm tươi '] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('NewsCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NewsCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412)): ?>
<?php $component = $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412; ?>
<?php unset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412); ?>
<?php endif; ?>
                    </div>

                </div>
            </div>
            
            <div class="col-12 col-lg-9">

                <div class="pro-xep">
                    <div class="pro-x d-flex align-items-center gap-2" style="flex-wrap: wrap;">
                        <strong>Sắp xếp:</strong>

                        <form  class="pro-text d-flex align-items-center gap-1" >
                              <input type="radio" id="" name="sort_by" value="name_asc" <?php echo e($request->get('sort_by') == 'name_asc' ? 'checked' : ''); ?>>
                              <label for="">A-Z</label>
                              <input type="radio" id="" name="sort_by" value="name_desc" <?php echo e($request->get('sort_by') == 'name_desc' ? 'checked' : ''); ?>>
                              <label for="">Z-A</label>
                              <input type="radio" id="" name="sort_by" value="price_asc" <?php echo e($request->get('sort_by') == 'price_asc' ? 'checked' : ''); ?>>
                              <label for="">Gía tăng dần</label>
                              <input type="radio" id="" name="sort_by" value="price_desc" <?php echo e($request->get('sort_by') == 'price_desc' ? 'checked' : ''); ?>>
                              <label for="">Giá giảm dần</label>
                              <input type="radio" id="" name="sort_by" value="newest" <?php echo e($request->get('sort_by') == 'newest' ? 'checked' : ''); ?>>
                              <label for="">Mới nhất</label>
                              <input type="radio" id="" name="sort_by" value="oldest" <?php echo e($request->get('sort_by') == 'oldest' ? 'checked' : ''); ?>>
                              <label for="">Cũ nhất</label>
                            <button class="btn btn-primary">Lọc</button>
                        </form>
                    </div>
                </div>

                <?php if(count($products)>0): ?>
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $price1="";
                    $price2=number_format($item->price_current);
                    if($item->discount>0){
                    $price1=number_format($item->price_current)."đ";
                    $price2=number_format($item->price_current-($item->price_current*$item->discount/100));
                    }
                    ?>
                    <div class="col-6  col-lg-3 mb-2 mt-2">
                        <?php if (isset($component)) { $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5 = $component; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['link' => ''.e(route('clientproduct-detail',['slug'=>$item->slug])).'','name' => ''.e($item->name).'','thumb' => ''.e($item->thumb).'','priceOld' => ''.e($price1).'','priceCurrent' => ''.e($price2).'đ','discount' => ''.e($item->discount).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ProductCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5)): ?>
<?php $component = $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5; ?>
<?php unset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5); ?>
<?php endif; ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <div class="alert alert-warning d-flex justify-content-center">Danh mục trống</div>

                <?php endif; ?>

                <div class="d-flex justify-content-center mt-3"><?php echo e($products->appends(request()->all())->links()); ?></div>

            </div>

        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>



<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo e(asset('./js/client/product.js')); ?>"></script>
<script src="<?php echo e(asset('js/client/product.js')); ?>"></script>
<script>
    var mySwiperNews = new Swiper(".mySwiperService", {
     slidesPerView: 2,
     spaceBetween: 20,
     navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        breakpoints: {
        0: {
          slidesPerView: 1,
          spaceBetween: 20,
          pagination: {
              el: ".swiper-pagination",
              dynamicBullets: true,

            },
        },
        640: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        1024: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
      },
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/products/index.blade.php ENDPATH**/ ?>