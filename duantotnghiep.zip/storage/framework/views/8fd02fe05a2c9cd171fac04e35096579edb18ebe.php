
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;
?>
<form action="<?php echo e(url('admin/news/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="container-fluid pt-4 px-4">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Tin rác</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Check</th>
                                            <th scope="col">Title</th>
                                            <th scope="col">Summary</th>
                                            <th scope="col">Author</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Category</th>
                             
                                            
                                            <th scope="col">Image</th>
                                            
                                            
                                            <th scope="col">Action</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="checkbox" name="check[]" value="<?php echo e($item->id); ?>"></td>
                                        <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e($item->summary); ?></td>
                                        <td>author</td>
                                        <td><?php echo e($item->created_at); ?></td>
                                         <td>
                                            <?php echo e($item->category_name); ?>

                                         </td>
                                        
                                        <td><img src="<?php echo e(asset('upload/'.$item->thumb)); ?>" alt="" width="100px" height="100px"></td>
                                         <td colspan="">
                                            <a href="<?php echo e(url('admin/news/capnhat/'.$item->id)); ?>" class="btn btn-primary">Sửa</a>
                                            <a href="<?php echo e(url('admin/news/xoa/'.$item->id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa không?')" class="btn btn-danger">Xóa</a>
                                             
                                        </td>
                                        
                                      
                                    </tr>
                                    <tr>
                                       
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                     

                                 <tfoot>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                         
                                        </td>
                                     
                                        <td>
                                      <style>
                                          .pagination{
                                                    display: flex;
                                                    justify-content: center;
                                                  }
                                                  .pagination a{
                                                    padding: 10px;
                                                    border: 1px solid #ccc;
                                                    margin: 0 5px;
                                                    text-decoration: none;
                                                    color: #000;
                                                  }
                                                  .pagination a.active{
                                                    background: green;
                                                    color: #fff;
                                                  }
                                      </style>     
                                     <div class="pagination">
    <?php if($news->currentPage() > 0): ?>
        <a href="<?php echo e($news->previousPageUrl()); ?>">Previous</a>
    <?php endif; ?>

    <?php for($i = 1; $i <= $news->lastPage(); $i++): ?>
        <a href="<?php echo e($news->url($i)); ?>" 
           class="<?php echo e(($news->currentPage() == $i) ? ' active' : ''); ?>">
           <?php echo e($i); ?>

        </a>
    <?php endfor; ?>

    <?php if($news->hasMorePages()): ?>
        <a href="<?php echo e($news->nextPageUrl()); ?>">Next</a>
    <?php endif; ?>
</div>
                                          
                                        </td>
                                        <td>
                                           
                                    

                                            <a href="<?php echo e(url('admin/news/them')); ?>" class="btn btn-primary">Thêm</a>
                                        <a href="<?php echo e(url('admin/news/phuc-hoi-tat-ca')); ?>" class="btn btn-primary">Phục hồi

                                        <span>
                                            (<?php
                                            $count = DB::table('news')->where('deleted_at','!=',null)->count();
                                            echo $count;
                                            ?>)
                                            
                                        </span>
                                        </a>
                                                <button type="submit" class="btn btn-danger">Xóa nhiều</button>
                                              
                                        </td>
                                    </tr>
                                 </tfoot>
                                </table>
                                
                            </div>
                        </div>
                    </div>
            
                </div>


</form>

<?php $__env->stopSection(); ?>

</form>

<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/news/trash.blade.php ENDPATH**/ ?>