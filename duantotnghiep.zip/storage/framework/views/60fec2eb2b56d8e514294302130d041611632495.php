
<?php $__env->startSection('main-content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/news_index.css')); ?>">
<div class="container" >
  <nav aria-label="breadcrumb  " style="<?php echo \Illuminate\Support\Arr::toCssStyles("border-bottom:1px solid #eae8e8; ") ?>">
    <ol class="breadcrumb p-3" style="<?php echo \Illuminate\Support\Arr::toCssStyles("margin:0;padding-left:0px") ?>">
      <li class="breadcrumb-item"><a href="<?php echo e(route('client')); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Liên hệ</li>
    </ol>
  </nav>

  
  <div class="main mt-2">
    <div class="main_content" style="width: 100%">
      <div class="row align-items-end">
        <div class="col-9">
          <div class="navbar-container">
            <h2 class="change_title">
              Mẹo ăn ngon
            </h2>
            <ul>
              <li class="nav-link active-link">
                <a href="#">Mẹo ăn ngon
                </a>
                <div class="underline"></div>
              </li>
              <li class="nav-link">
                <a href="#">Vào bếp cùng Mew</a>
                <div class="underline"></div>
              </li>
              <li class="nav-link">
                <a href="#">Review ẩm thực</a>
                <div class="underline"></div>
              </li>
              <li class="nav-link">
                <a href="#">Khuyến mãi hot</a>
                <div class="underline"></div>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-3">
          <div class="popular_news_title">
            <h4>Tin tức nổi bật</h4>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-9">
          <div style="display: grid;grid-template-columns:repeat(3,1fr);gap :10px;margin-top: 20px;">

            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412 = $component; } ?>
<?php $component = App\View\Components\NewsCard::resolve(['isRow' => ''.e(false).'','link' => ''.e(route('clientnews-detail',['slug'=>$item->slug])).'','title' => ''.e($item->title).'','thumb' => ''.e($item->thumb).'','summary' => ''.e($item->summary).'','day' => ''.e($item->created_at->format('d')).'','month' => ''.e($item->created_at->format('m/Y')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('NewsCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NewsCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412)): ?>
<?php $component = $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412; ?>
<?php unset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412); ?>
<?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="d-flex justify-content-center mt-4"><?php echo e($news->appends(request()->all())->links()); ?></div>
        </div>
        <div class="col-3 mt-3" >
          <div class="popular_news" style=" height: 100%;width: 90%;">
            <ul style="padding: 0">
              <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li>
                  <?php if (isset($component)) { $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412 = $component; } ?>
<?php $component = App\View\Components\NewsCard::resolve(['isRow' => ''.e(true).'','link' => ''.e(route('clientnews-detail',['slug'=>$item->slug])).'','title' => ''.e($item->title).'','thumb' => ''.e($item->thumb).'','summary' => ''.e($item->summary).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('NewsCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NewsCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412)): ?>
<?php $component = $__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412; ?>
<?php unset($__componentOriginal114ad97837f9acea83443ad1f7b04b3bb4eda412); ?>
<?php endif; ?>
                 </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </ul>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>

<script>
  $('.nav-link').on('click', function() {
	$('.active-link').removeClass('active-link');
	$(this).addClass('active-link');
});
</script>
<script>
  var title = document.getElementsByClassName("change_title");
            var nav_link = document.getElementsByClassName("nav-link");
            var underline = document.getElementsByClassName("underline");
            for (let i = 0; i < nav_link.length; i++) {
              nav_link[i].addEventListener("click", function () {
                for (let j = 0; j < nav_link.length; j++) {
                  nav_link[j].classList.remove("active-link");
                  underline[j].style.width = "0";
                }
                nav_link[i].classList.add("active-link");
                underline[i].style.width = "100%";
                title[0].innerHTML = nav_link[i].innerText;
              });
            }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/news/index.blade.php ENDPATH**/ ?>