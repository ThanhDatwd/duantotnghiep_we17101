
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="bg-light rounded h-100 p-4">
 <div class="text">
  <h2 class="">DANH SÁCH SẢN PHẨM </h2>
  
  <a href="/admin/product/create"><i class="fa-solid fa-circle-plus"></i> Thêm sản phẩm</a>
 </div>
  <?php if(Session::has('thongbao')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('thongbao')); ?>

    </div>
  <?php endif; ?>
</a>
  <div class="table-responsive">
      <table class="table">
          <thead>
              <tr>
                  <th></th>
                  <th scope="col">ID</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Tên sản phẩm</th>
                  <th scope="col">Giảm giá</th>
                  <th scope="col">Đơn giá</th>
                  <th scope="col">Trạng thái</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <th><?php echo e($p->id); ?></th>
                  <td><img src="<?php echo e(asset('upload/'.$p->thumb)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" >
                  </td>
                  
                  <td>
                    <p style="font-size: 18px; font-weight:bold"><?php echo e($p->name); ?></p>
                    <span>Loại: <?php echo e($p->category->category_name ?? 'Chưa phân loại'); ?></span><br>
                    <span>Xuất sứ: <?php echo e($p->brand); ?></span>
                  </td>

                  <td><?php echo e($p->discount); ?> %</td>
                  <td> 
                    <span>Mới: <?php echo e(number_format($p->price_current, 0)); ?> vnđ </span><br>
                    <small>Cũ: <?php echo e(number_format($p->price, 0)); ?> vnđ</small>
                  </td>
                  <td>
                    <span>
                      <?php if(($p->is_active)==1): ?>
                      <button type="button" class="btn btn-success">Còn hàng</button>
                      <?php else: ?>
                      <button type="button" class="btn btn-danger">Hết hàng</button>                  
                    <?php endif; ?>
                    </span>
                  </td>
                  
                  <td class="button">
                    <a style="color: cadetblue" href="/admin/product/update/<?php echo e($p->id); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                    <a style="color: red" href="/admin/product/delete/<?php echo e($p->id); ?>" onclick="return myFunction();"> <i onclick="myFunction()" class="fa-sharp fa-solid fa-trash"></i> </a>

                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
                     </script>
                  </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <nav aria-label="Page navigation example">
        <ul class="pagination">
     
            <?php echo e($products->appends(request()->all())->links()); ?>  
         
      
        </ul>
      </nav>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/product/index.blade.php ENDPATH**/ ?>