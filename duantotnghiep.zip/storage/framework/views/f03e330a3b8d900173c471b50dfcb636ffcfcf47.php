
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/detailorder.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container row m-0 " style="max-width:100%">
    
    <div class=" user col-7 pt-4">
        <div class="d-flex align-items-center mb-4">
            <div class="fw-bold" style="font-size: 20px">Sản phẩm nhập hàng</div>
        </div>
        <div class="box-inner-1 pb-3 mb-3 ">
            <div id="my" class="carousel slide carousel-fade img-details" data-bs-ride="carousel"
                data-bs-interval="2000">
                <div class="carousel-inner" style="height: 0%">
                    <div class="carousel-item active">
                        <style>
                            .sanpham {
                                display: flex;
                                background: #fff;
                                margin-bottom: 10px;
                                border-radius: 4px;
                                padding: 0 8px;
                            }

                            .sanpham .box {
                                margin: 8px 10px;

                            }

                            .sanpham .box2 {
                                width: 100%;
                            }

                            .sanpham .box img {
                                width: 70px
                            }

                            .boxx {
                                display: flex;
                                border-top: 1px solid darkgray;
                                padding-top: 10px;
                                gap: 20px;
                            }

                            .boxx .left ,
                            .boxx .right {
                                font-size: 12px
                            } 
                            
                            .boxname {
                                width: 100%;
                                font-size: 14px;
                                text-transform: capitalize;

                            }

                            .boxname h4 {
                                font-size: 14px
                            }
                        </style>
                        <?php $__currentLoopData = $purchase_history_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sanpham">
                            <div class="box box1">
                                <img  src="<?php echo e(asset('upload/'.$od->thumb)); ?>"
                                    onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" class="orderDetaiProductImg" alt="">
                            </div>
                            <div class="box box2 ">
                                <div class="boxcon boxname">
                                    <h4><?php echo e($od->name); ?></h4>
                                </div>
                                <div class="boxcon boxx">
                                    <div class="right">Số lượng: <?php echo e($od->quantity); ?></div>
                                    <div class="left">Giá nhập: <?php echo e(number_format($od->cost)); ?> Vnđ</div>
                                </div>

                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

            </div>
            <p class="dis info my-3">
            </p>
            <div class="radiobtn">
                <input type="radio" name="box" id="one">
                <input type="radio" name="box" id="two">
                <input type="radio" name="box" id="three">
        
            </div>
        </div>
    </div>
    <div class="col-5 pt-4">
        <div class="box-inner-2">
            <div class="d-flex align-items-center mb-4">
                <div class="fw-bold" style="font-size: 20px">Thông tin đơn đặt hàng</div>
            </div>
            <form action="/admin/order/detail/<?php echo e($purchase_history->id); ?>" enctype="multipart/form-data" method="post">
                <div>
                    <div class="mb-2">
                        <p class="dis fw-bold mb-2">Nhân viên nhập hàng</p>
                        <?php if($purchase_history->created_by==null): ?>
                           <input class="form-control" type="text" disabled value="Admin">
                        <?php else: ?>
                           <input class="form-control" type="text" disabled value="<?php echo e($purchase_history->created_by); ?>">
                            
                        <?php endif; ?>
                    </div>
                    <div class="my-3">
                        <p class="dis fw-bold mb-2">Mã đơn hàng</p>
                        <input class="form-control" type="text" disabled value="<?php echo e($purchase_history->purchase_code); ?>">
                    </div>
                    <div class="my-3">
                        <p class="dis fw-bold mb-2">Đối tác nhập hàng</p>
                        <?php if($purchase_history->brand==null): ?>
                           <input class="form-control" type="text" disabled value="(Không nhập mục này)">
                        <?php else: ?>
                           <input class="form-control" type="text" disabled value="<?php echo e($purchase_history->brand); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="mb-2">
                        <p class="dis fw-bold mb-2">Trạng thái</p>
                        <select name="status" class="form-select">
                            <?php if($purchase_history->purchase_status == 1): ?>
                            <option value="1" selected>Hoàn thành </option>
                            <?php elseif($purchase_history->purchase_status == 0): ?>
                            <option value="2" selected>Xác nhận</option>
                            <option value="1">Hoàn thành</option>
                            <?php endif; ?>

                        </select>
                    </div>
                    <br>
                    <div class="d-flex flex-column dis">
                        
                        
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <p class="fw-bold">Tổng</p>
                            <p class="fw-bold"><?php echo e(number_format($purchase_history->total_cost)); ?> VNĐ</p>
                        </div>

                        <?php if($purchase_history->purchase_status == 0): ?>
                        <div class="btn btn-primary mt-2"><button type="submit"
                            style="background: none; border:none;color:aliceblue">Cập nhật</button>
                         </div>
                        <?php endif; ?>
                        
                    </div>
                </div>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
    
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/purchase/historyDetail.blade.php ENDPATH**/ ?>