
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">
<style>
    #btn-replaceImage,
    #btn-replaceImagePoster {
        display: block
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<form action="/admin/product/update/<?php echo e($p->id); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="adproduct">

        <h2>CẬP NHẬT SẢN PHẨM</h2>
        
        <div class= "container-fluid">
            <div class= "row">
               <div class ="col-md-8 col-sm-6 ">
                <div class="boxlist1">
                    <div class="addpro">
                       
                        <div class="adpro1">
                            <p>Tên sản phẩm <span>(*)</span></p>
                            <input type="text" value="<?php echo e($p->name); ?>" name="name" placeholder="Nhập tên sản phẩm">
                        </div>
                     
                
                    </div>
                    <div class="addpro">        
                        <div class="adpro1">
                            <p>Loại sản phẩm <span>(*)</span></p>
                            <select name="category_id">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($p->category_id==$c->id): ?>
                                <option selected value="<?php echo e($c->id); ?>"><?php echo e($c->category_name); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($c->id); ?>"><?php echo e($c->category_name); ?></option>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                     
                
                    </div>
                    <div class="addpro">
                        <div class="adpro1">
                            <p>Giá <span>(*)</span></p>
                            <input type="number" value="<?php echo e($p->price); ?>"  name="price" placeholder="Nhập giá bán">
                        </div>
                        
                        <div class="adpro1">
                            <p>Giá bán <span>(*)</span></p>
                            <input type="number" name="price_current" value="<?php echo e($p->price_current); ?>" placeholder="Nhập giá bán">
                        </div>
                        <div class="adpro1">
                            <p>Giảm giá</p>
                            <input type="number" name="discount" min="0" max="100" value="<?php echo e($p->discount); ?>" placeholder="Nhập giá bán">
                        </div>   
                    </div>
                <div class="addpro">
                   <div class="adpro1" style="width:200px">
                       <p>Xuất xứ</p>
                       <select name="brand"> 
                     <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($p->brand == $b->brands): ?>
                     <option selected value="<?php echo e($b->brands); ?>"><?php echo e($b->brands); ?></option>
                     <?php else: ?>   
                      <option value="<?php echo e($b->brands); ?>"><?php echo e($b->brands); ?></option>
                     <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                       
                       </select>
                   </div>
                 
                   <div class="adpro1" style="width:200px">
                    <p>Đơn vị <span>(*)</span></p>
                    <select name="unit">
                        <option value="<?php echo e($p->unit); ?>"><p><?php echo e($p->unit); ?></p></option>
                        <option value="kg">Kg</option>
                        <option value="tấn">Tấn</option>
                        <option value="tạ">Tạ</option>
                
                    </select>
                </div>
                  
                </div>
                
                
                    <div class="addpro">
                        <div class="adpro1">
                            <p>Mô tả ngắn <span>(*)</span></p>
                            <textarea name="summary" id="" style="width:100%" cols="100" rows="5"><?php echo e($p->summary); ?></textarea>
                        </div>
                    </div>
                    <div class="addpro">
                        <div class="adpro1">
                            <p>Trạng thái</p>
                            <select name="is_active">
                                <?php if(($p->is_active)=='1'): ?>
                                <option value="1" selected >Còn hàng</option>
                                <option value="0" >Hết hàng</option>
                                <?php else: ?>
                                <option value="1" >Còn hàng</option>
                                <option value="0" selected>Hết hàng</option>   

                                <?php endif; ?>
                               
                            </select>
                        </span>
                
                        </div>
                    </div>
                
                    <div class="addpro">
                        <div class="adpro1">
                         
                                <script type="text/javascript" src="https://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
                                <p>Mô tả <span>(*)</span></p>
                                <textarea id="editor1" name="content"><?php echo e($p->content); ?></textarea>            
                                              </div>
                       </div>
                </div>
                
                
               </div>
               <div class ="col-md-4 col-sm-6 ">
        <script src="https://www.dukelearntoprogram.com/course1/common/js/image/SimpleImage.js"></script>
        <div class="addpro" >
            <div class="adpro1">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <strong>Ảnh<span>(*)</span></strong>
                    <button class="btn btn-sm btn-light "  id="btn-replaceImage">Thay thế</button>
                </div>
                <div  id="cvas1">
                    <?php if($p->thumb==null): ?>
                    <div id="iconUpload">
                        <i class="bi bi-upload"></i>
                    </div>
                    <?php endif; ?>
                    <img src="<?php echo e(asset('upload/'.$p->thumb)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'">
                    <canvas id="imagePreviewUpload"></canvas>
                </div>
                <br>
                <input name="thumb" hidden  value="<?php echo e(asset('upload/')); ?>" type="file" id="image" multiple="false" accept="<?php echo e(asset('upload/news.jpg')); ?>" onchange="uploadIm()"/><br>
                <script>
                    var img = <?php echo e($p->thumb); ?>;
                    const input = document.querySelector("input[type=file]");
                    input.value = img;
                </script>

            </div>
        </div>
            
        </div>
               </div>
               <div class="ci">
                   <button type="submit" class="btnmoi">Cập nhật</button>
                  <a href="/admin/product">Hủy</a>
                  </div>
               </div>
            </div>
         </div>
        
        </div>
                  
        
    
    </div>
</form>
<script>
    window.CP.PenTimer.MAX_TIME_IN_LOOP_WO_EXIT = 6000;
    var drawGray = null;
    function uploadIm(){
        var canvas = document.getElementById("imagePreviewUpload");
        var image = document.getElementById("image");
        var draw = new SimpleImage(image);
        drawGray = new SimpleImage(image);
        $("#iconUpload").hide(100)
        draw.drawTo(canvas);
    }
</script>
<script>
    var editor = CKEDITOR.replace( 'editor1' );

// The "change" event is fired whenever a change is made in the editor.
editor.on( 'change', function( evt ) {
  $('#hiddedn input').val(evt.editor.getData());
});
$("#btn-replaceImage").click(function (e) { 
    e.preventDefault();
    $("#image").click()
});
$("#iconUpload").click(function (e) { 
        e.preventDefault();
        $("#image").click()
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/product/update.blade.php ENDPATH**/ ?>