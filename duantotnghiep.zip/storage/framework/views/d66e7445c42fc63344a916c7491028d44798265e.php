
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;
?>
<form action="<?php echo e(url('admin/comment/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="p-4">
    <?php if(Session::has('thongbao')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('thongbao')); ?>

    </div>
    <?php endif; ?>
    <div class="text-start">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <div>Danh sách nhóm loại sản phẩm</div>
          <div class="adding">
            <a href="/admin/category_group/create"><i class="fa-solid fa-circle-plus fs-3"></i></a>
          </div>
        </div>
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-hover align-middle">
            <thead class="text-dark table-info">
          <tr>
            <th></th>
            <th scope="col">Check</th>
            <th scope="col">Nội dung</th>
            <th scope="col">Tên tài khoản</th>

            <th scope="col">Chỉnh sửa</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th></th>
            <td><input type="checkbox" name="check[]" value="<?php echo e($item->id); ?>"></td>
            <td><?php echo e($item->content); ?></td>
            <?php 
                $user = DB::table('users')->where('id',$item->user_id)->first();
                ?>
            <td><?php echo e($user->name); ?></td>
            <td class="button">
              <a style="color: red" href="<?php echo e(url('admin/comment/xoa/'.$item->id)); ?>" onclick="return myFunction();"> <i
                  class="fa-sharp fa-solid fa-trash"></i> </a>
              <script>
                function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
              </script>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>
<div class="mt-2">
<nav aria-label="Page navigation example ">
  <ul class="pagination">
    <?php echo e($comment->appends(request()->all())->links()); ?>  
  </ul>
</nav>
</div>
</div>






</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/comment/index.blade.php ENDPATH**/ ?>