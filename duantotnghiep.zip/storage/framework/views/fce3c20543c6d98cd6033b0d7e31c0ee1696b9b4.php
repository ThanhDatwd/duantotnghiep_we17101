
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/admin/profile/profile.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-6" style="width: 40%">
            <div class="bg-light rounded h-100 p-4">

                <div class="character">
                    <div class="avatar">

                    </div>
                    <div class="stats">
                        <ul>

                            <li><i class="fa fa-fw fa-shield"></i>Chức vụ: <span id="con">Admin</span></li>
                            <li><i class="fa fa-fw fa-book"></i>Tình trạng làm việc: <span id="int">Hoạt động</span>
                            </li>
                            <li><i class="fa fa-fw fa-eye"></i>Số lượng bài viết: <span id="per">
                                    <?php echo e($count_news); ?>

                                </span></li>
                        </ul>
                    </div>
                    <hr />
                    <h1>Admin<span>
                            <?php echo e(Auth::guard('admin')->user()->username); ?>

                        </span></h1>
                </div>
                
           <div class="row g-4" style="margin-top: 30px">
            <form action="<?php echo e(url('admin/news/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
                         <?php echo csrf_field(); ?>

                 
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Danh sách tin tức bạn viết</h6>
                            <div class="table-responsive">
                       <table class="table">
                     <thead>
                     <tr>
                  <th></th>
                  <th scope="col">Check</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Tiêu đề</th>
                  <th scope="col">Nội dung</th>
                  <th scope="col">Tác giả</th>
                  <th scope="col">Chỉnh sửa</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $count_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <td><input type="checkbox" name="check[]" value="<?php echo e($item->id); ?>"></td>
                  <td><img src="<?php echo e(asset('upload/'.$item->thumb)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" >
                  </td>
                  
              <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e($item->summary); ?></td>
                                        <td>
                                            <?php echo e($item->created_by); ?>

                                        </td>

                
                
                  
                  
                  <td class="button">
                    <a style="color: cadetblue" href="<?php echo e(url('admin/news/capnhat/'.$item->id)); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                    <a style="color: red" href="<?php echo e(url('admin/news/xoa/'.$item->id)); ?>" onclick="return myFunction();"> <i  class="fa-sharp fa-solid fa-trash"></i> </a>
                   
                

                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
                                    </script>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination" style="display: flex;justify-content:space-between;">



                            <li>
                                <a href="<?php echo e(url('admin/news/them')); ?>" class="btn btn-primary">Thêm</a>

                                <a href="<?php echo e(url('admin/news/thung-rac')); ?>" class="btn btn-primary">Thùng rác
                                    <?php
                                                $count = DB::table('news')->where('deleted_at','!=',null)->count();
                                                ?>
                                    (<?php echo e($count); ?>)

                                </a>
                                <button type="submit" class="btn btn-danger">Xóa nhiều</button>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="container-fluid pt-4 px-4">


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>