
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;
?>
<form action="<?php echo e(url('admin/news/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

                 
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Quản lý tin tức</h6>
                            <div class="table-responsive">
                       <table class="table">
                     <thead>
                     <tr>
                  <th></th>
                  <th scope="col">Check</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Tiêu đề</th>
                  <th scope="col">Nội dung</th>
                  <th scope="col">Tác giả</th>
                  <th scope="col">Chỉnh sửa</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <td><input type="checkbox" name="check[]" value="<?php echo e($item->id); ?>"></td>
                  <td><img src="<?php echo e(asset('upload/'.$item->thumb)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" >
                  </td>
                  
              <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e($item->summary); ?></td>
                                        <td>
                                            <?php echo e($item->created_by); ?>

                                        </td>

                
                
                  
                  
                  <td class="button">
                    <a style="color: cadetblue" href="<?php echo e(url('admin/news/capnhat/'.$item->id)); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                    <a style="color: red" href="<?php echo e(url('admin/news/xoa/'.$item->id)); ?>" onclick="return myFunction();"> <i  class="fa-sharp fa-solid fa-trash"></i> </a>
                   
                

                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
                     </script>
                  </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        
          
      </table>


                                
                                  <nav aria-label="Page navigation example">
        <ul class="pagination" style="display: flex;justify-content:space-between;">
     
           <li> <?php echo e($news->appends(request()->all())->links()); ?>  </li>
          
           <li>
              <a href="<?php echo e(url('admin/news/them')); ?>" class="btn btn-primary">Thêm</a>
                                                  
                                            <a href="<?php echo e(url('admin/news/thung-rac')); ?>" class="btn btn-primary">Thùng rác
                                                <?php
                                                $count = DB::table('news')->where('deleted_at','!=',null)->count();
                                                ?>
                                                (<?php echo e($count); ?>)
                                                
                                            </a>
                                                <button type="submit" class="btn btn-danger">Xóa nhiều</button>
                  </li>
         
      
        </ul>
      </nav>
                            </div>
                        </div>
                    
            
            


</form>

<?php $__env->stopSection(); ?>

</form>
  


 
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/news/index.blade.php ENDPATH**/ ?>