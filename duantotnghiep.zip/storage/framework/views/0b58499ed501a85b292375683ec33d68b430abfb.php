
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/client/productDetail.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success">
  <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<section class="container">
  <nav aria-label="breadcrumb  " style="<?php echo \Illuminate\Support\Arr::toCssStyles("border-bottom:1px solid #eae8e8; ") ?>">
    <ol class=" breadcrumb p-3" style="<?php echo \Illuminate\Support\Arr::toCssStyles("margin:0;padding-left:0px") ?>">
    <li class="breadcrumb-item"><a href="<?php echo e(route('client')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
    </ol>
  </nav>
</section>
<section class="product-detail grid container mt-4">
  <div class="">
    <h1 class="product-name font-weight-bold text-uppercase mb-3"><?php echo e($product->name); ?></h1>
    <div class="product-detail--infos">
      <div class="product-detail--img">
        <div class="swiper mySwiperProductDetailThumb">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <img src="<?php echo e(asset('upload/'.$product->thumb)); ?>" alt=""
                onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" />
            </div>
            <?php $__currentLoopData = $product->products_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
              <img src="<?php echo e(asset('upload/'.$product_images->url)); ?>" alt=""
                onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiperProductDetailGallery">
          <div class="swiper-wrapper">
            <?php $__currentLoopData = $product->products_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
              <img src="<?php echo e(asset('upload/'.$product_images->url)); ?>" alt=""
                onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        
        
      </div>
      <div class="product-detail--info">
        <div class="product-detail--info__status">Tình trạng:
          <span><?php echo e($product->quantity_output>=$product->quantity_input?"Cháy hàng":"Còn hàng"); ?></span> | Thương hiệu:
          <span>Green Food</span></div>
        <div class="product-detail--info__prices">
          <?php if($product->discount>0): ?>
          <div class="product-detail--info__price-new">
            <?php echo e(number_format(($product->price_current-($product->price_current*$product->discount/100)))); ?><span>
              vnđ</span></div>
          <div class="product-detail--info__price-old"><?php echo e(number_format($product->price_current)); ?><span> vnđ</span></div>
          <?php else: ?>
          <div class="product-detail--info__price-old"><?php echo e($product->price_current); ?><span> vnđ</span></div>
          <?php endif; ?>
        </div>
        <form id="form-add" method="post" action=<?php echo e(route('clientadd-to-cart')); ?>>
          <input type="text" hidden name="productId" value=<?php echo e($product->id); ?>>
          <div class="form-group">
            <label for="">Số Lượng</label>
            <div class="form-amount">
              <div class="btn btn-amount desc"><i class='bx bx-minus'></i></div>
              <input class="input-amount" type="number" name="amount" value=1>
              <div class="btn btn-amount add"><i class='bx bx-plus'></i></div>
            </div>
          </div>
          <?php echo csrf_field(); ?>
          <div class="product-detail--info__cta">
            <?php if($product->quantity_input>$product->quantity_output): ?>
            <button class="btn btn-1" id="btn_add_to_card">Thêm vào giỏ hàng</button>
            <button class="btn btn-2" id="btn_buy_now">Mua ngay</button>
            <?php else: ?>
            <button class="btn btn-success py-1 d-flex gap-2 align-items-center justify-content-center w-auto"
              disabled><i class="bi bi-cart4 fs-5"></i> <span>Cháy hàng</span></button>
            <?php endif; ?>

          </div>
        </form>
        <div class="linehot_pro alert alert-warning mt-3 mb-3 d-flex align-items-center">
          <img class="mr-3 lazy loaded" alt="1900 123 321"
            src="//bizweb.dktcdn.net/100/434/011/themes/845632/assets/customer-service.png?1676652183181"
            data-src="//bizweb.dktcdn.net/100/434/011/themes/845632/assets/customer-service.png?1676652183181">
          <div class="b_cont font-weight-bold ml-3">
            <span class="d-block">
              Gọi ngay <a href="tel:1900123321" title="1900688688">1900 688 688</a> để được tư vấn tốt nhất!
            </span>
          </div>
        </div>
        <div class="btn-shopee">
          <img src="https://bizweb.dktcdn.net/100/434/011/themes/845632/assets/shopee_buy.png?1676652183181" alt="">
        </div>
      </div>
    </div>
    <div class="mt-4">
      <?php if(count(json_decode($coupons))>=1): ?>
      <?php if (isset($component)) { $__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14 = $component; } ?>
<?php $component = App\View\Components\CouponCard::resolve(['list' => $coupons] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('AppCouponCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CouponCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14)): ?>
<?php $component = $__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14; ?>
<?php unset($__componentOriginalfd6ff7180efb39f3f2e514f172060e2e564d5f14); ?>
<?php endif; ?>
      <?php endif; ?>
    </div>
    <div class="product-detail--other mt-4">
      <h3 class="title underline">Thông tin chi tiết</h3>
      <div><?php echo $product->content!=""?$product->content:'Đang cập nhật'; ?></div>
    </div>
  </div>
  <div class="related-products d-sm-block d-none">
    <h2 class="title mb-3 text-uppercase font-weight-bold position-relative ">
      <a href="">Sản phẩm liên quan</a>
      <div class="position-relative">
        <span class="swiper-button-prev mre_prev "></span>
        <span class="swiper-button-next mre_next "></span>
      </div>
    </h2>
    <div class="sidebar">
      <div class="products-row">
        <div class="swiper mySwiperRelatedProducts">
          <div class="swiper-wrapper">
            <?php $__currentLoopData = $product_relate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $price1=0;
            $price2=$item->price_current;
            if($item->discount>0){
            $price1=$item->price_current;
            $price2=$item->price_current-($item->price_current*$item->discount/100);

            }
            ?>
            <div class="swiper-slide">
              <?php if (isset($component)) { $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5 = $component; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['link' => ''.e(route('clientproduct-detail',['slug'=>$item->slug])).'','isRow' => ''.e(true).'','name' => ''.e($item->name).'','thumb' => ''.e($item->thumb).'','priceOld' => ''.e(number_format($price1)).'','priceCurrent' => ''.e(number_format($price2)).'','discount' => ''.e($item->discount).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ProductCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5)): ?>
<?php $component = $__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5; ?>
<?php unset($__componentOriginal5e109b4b7def75bd69cfe491f655f877e39a59a5); ?>
<?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          
        </div>
      </div>

      <img
        src="https://scontent.fsgn2-7.fna.fbcdn.net/v/t39.30808-6/219284243_343850734042591_481454821461992375_n.jpg?stp=dst-jpg_p843x403&_nc_cat=100&ccb=1-7&_nc_sid=730e14&_nc_ohc=Vb6Lj4eKW_UAX-LO1Y0&_nc_ht=scontent.fsgn2-7.fna&oh=00_AfA9Wfgfk21Tv5KIwq09B_fa0r05CmM1OeLxpomr6zw9EQ&oe=63F885EA"
        alt="" class="banner">
    </div>
  </div>
</section>
<section class="container" style="margin-top: 20px">

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  var mySwiperProductDetailGallery = new Swiper(".mySwiperProductDetailGallery", {
      spaceBetween: 10,
      slidesPerView: 4,
      freeMode: true,
      watchSlidesProgress: true,
    });
    var mySwiperProductDetailThumb = new Swiper(".mySwiperProductDetailThumb", {
      spaceBetween: 10,
      thumbs: {
        swiper: mySwiperProductDetailGallery,
      },
    });
    var mySwiperRelatedProducts = new Swiper(".mySwiperRelatedProducts", {
     slidesPerView: 1,
     spaceBetween: 10,
     navigation: {
       nextEl: ".mre_next",
       prevEl: ".mre_prev",
      },
      grid:{
             rows:4
           }
    //     breakpoints: {
    //     0: {
    //       slidesPerView: 2,
    //       spaceBetween: 20,
    //       grid:{
    //         rows:2
    //       }
    //     },
    //     768: {
    //       slidesPerView: 3,
    //       spaceBetween: 20,
    //     },
    //     1024: {
    //       slidesPerView: 4,
    //       spaceBetween: 20,
    //     },
    //   },
   });

  //  PHẦN CSS CHO THÊM SỐ LƯỢNG SẢN PHẨM
  const formAdd = document.querySelector('#form-add')
    const productId = document.querySelector('[name=productId]').value
    const amount = formAdd.querySelector('.input-amount')
    const btnAdd = formAdd.querySelector('.btn-amount.add')
    const btnDesc = formAdd.querySelector('.btn-amount.desc')
    const btn_add_to_card=$('#btn_add_to_card')
    const btn_buy_now=$('#btn_buy_now')

    btn_buy_now.click((e)=>{
      e.preventDefault();
      formAdd.action='http://127.0.0.1:8000/buy-now';
      formAdd.submit()
      console.log(formAdd.acction)
    })
    btn_add_to_card.click((e)=>{
      formAdd.action='http://127.0.0.1:8000/add-to-cart';
      e.preventDefault();
      formAdd.submit()

    })
    const btnOrderNow = formAdd.querySelector('.btnOrder-now')
    btnAdd.onclick = () => {
        amount.value++
    }
    btnDesc.onclick = () => {
      if (amount.value > 1) {
          amount.value--
        }
    }
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/client/productDetail/index.blade.php ENDPATH**/ ?>