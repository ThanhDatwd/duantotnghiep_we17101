
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="bg-light rounded h-100 p-4">
 <div class="text">
  <h2 class="">Danh sách loại sản phẩm</h2>
  <a href="/admin/product_category/create"><i class="fa-solid fa-circle-plus"></i> Thêm loại sản phẩm</a>
 </div>

  <?php if(Session::has('thongbao')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('thongbao')); ?>

    </div>
  <?php endif; ?>
</a>

  <div class="table-responsive">
      <table class="table">
          <thead>
              <tr>
                  <th></th>
                  <th scope="col">ID</th>
                  <th scope="col">Hình ảnh</th>
                  <th scope="col">Tên sản phẩm</th> 
                  <th scope="col">Thứ tự hiện</th>
                  <th scope="col">Trạng thái</th>
                  <th scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th></th>
                  <th><?php echo e($c->id); ?></th>
                  <td><img src="<?php echo e(asset('upload/'.$c->thumb)); ?>" alt="" onerror="this.src='<?php echo e(asset('upload/error.jpg')); ?>'" >
                  </td>
                  
                  <td>
                    <p style="font-size: 18px; font-weight:bold"><?php echo e($c->category_name); ?></p>
                    <p><?php echo e($c->slug); ?></p>
                  </td>
                  <td><?php echo e($c->stt); ?></td>
                 
                 <td>
                    <span>
                      <?php if(($c->is_active)==1): ?>
                      <button type="button" class="btn btn-success">Hiện</button>
                      <?php else: ?>
                      <button type="button" class="btn btn-danger">Ẩn</button>                  
                    <?php endif; ?>
                    </span>
                  </td>
                  
                  <td class="button">
                    <a style="color: cadetblue" href="/admin/product_category/update/<?php echo e($c->id); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                    <a style="color: red" href="/admin/product_category/delete/<?php echo e($c->id); ?>" onclick="return myFunction();"> <i onclick="myFunction()" class="fa-solid fa-trash-can"></i> </a>
                    
                    <script>
                      function myFunction() {
                          if(!confirm("Bạn có chắc chắn muốn xóa không!!"))
                          event.preventDefault();
                      }
                     </script>
                  </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <nav aria-label="Page navigation example">
        <ul class="pagination">
     
            <?php echo e($categories->appends(request()->all())->links()); ?>  
         
      
        </ul>
      </nav>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/product_category/index.blade.php ENDPATH**/ ?>