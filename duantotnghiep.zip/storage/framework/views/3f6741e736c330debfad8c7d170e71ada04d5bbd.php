
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/product/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .show-mail-area .subtitle {
        font-size: 28px;
        font-weight: 400
    }

    .row-content {
        gap: 16px;
        padding: 10px 0;
    }

    .row-content .col-left {
        width: 40px;

    }

    .row-content .col-left img {
        width: 100%;
        border-radius: 50%
    }

    .row-content .col-right {
        width: calc(100% - 50px);
    }

    .col-right.info span,
    .col-right.info em {
        font-size: 12px;
        line-height: 4px
    }

    .col-right.reply {
        background: #fff;
        box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px
    }
    #reply-area{
        display: none
    }
    #reply-area.active{
        display: block
    }
</style>
<div class="show-mail-area p-4">
    <div class="row-content d-flex">
        <div class="col-left">
        </div>
        <div class="col-right d-flex align-items-center justify-content-between">
            <h4 class="subtitle"><?php echo e($email->subject); ?></h4>
            <div class="d-flex align-items-center gap-4">
                <i class="bi bi-printer"></i>
                <i class="bi bi-box-arrow-in-up-right"></i>
            </div>
        </div>
    </div>
    <div class="row-content d-flex align-items-center">
        <div class="col-left">
            <img src="https://lh3.googleusercontent.com/a/default-user=s40-p" alt="">
        </div>
        <div class="col-right info d-flex align-items-center justify-content-between">
            <div>
                <div>
                    <strong><?php echo e($email->custommer_name); ?></strong>
                    <em><?php echo e($email->from); ?></em>
                </div>
                <div>
                    <span>Đến tôi</span>
                </div>
            </div>
            <div class="action d-flex align-items-center gap-4">
                <span><?php echo e(date_format($email->created_at,"H:i:s d/m/Y")); ?> <?php echo e(ceil(strtotime(date('Y-m-d'))-strtotime($email->created_at))/86400); ?> ngày trước</span>
                <i class="bi bi-star"></i>
                <i class="bi bi-reply"></i>
                <i class="bi bi-three-dots"></i>
            </div>
        </div>
    </div>
    <div class="row-content d-flex">
        <div class="col-left"></div>
        <div class="col-right">
            <p class="body">
               <?php echo e($email->content); ?>

            </p>
        </div>
    </div>
    <div class="row-content d-flex action">
        <div class="col-left"></div>
        <div class="col-right">
            <div class="btn btn-light btn-outline-secondary rounded-pill btn-reply "><i class="bi bi-reply"></i> Phản hồi</div>
            <div class="btn  btn-light btn-outline-secondary rounded-pill"> <i class="bi bi-trash"></i> Xóa</div>
        </div>
    </div>
    <div id="reply-area">
        <div class="row-content d-flex reply ">
            <div class="col-left">
                <img src="https://bizweb.dktcdn.net/100/434/011/themes/845632/assets/favicon.png?1667206835361" alt="">
            </div>
            <div class="col-right reply">
                <textarea id="editorReplyEmail" name="content_reply"></textarea>
                <div class="d-flex align-items-center justify-content-between mt-3">
                    <div class="btn btn-primary rounded-pill btn-sendMail "> <i class="bi bi-reply"></i> Gửi</div>
                 
                    <div class="btn btn-light rounded-pill btn-cancel-mail"> <i class="bi bi-trash"></i> Hủy</div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        let rowRepply=$('.row-content.reply')
    $('.btn-reply').click(function (e) { 
        e.preventDefault();
        console.log('xin chòa')
        $("#reply-area").toggle(1000);        
    });
    $('.btn-cancel-mail').click(function (e) { 
        e.preventDefault();
        $("#reply-area").hide(1000);
        $('#editorReplyEmail').val("")  
        
    });
    var editorReplyEmail = CKEDITOR.replace( 'editorReplyEmail' );
    editorReplyEmail.on( 'change', function( evt ) {
    $('#editorReplyEmail').val(evt.editor.getData());
    });
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>