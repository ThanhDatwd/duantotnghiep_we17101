
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;
?>
<form action="<?php echo e(url('admin/categories_news/xoa-nhieu')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="container-fluid pt-4 px-4">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Quản lý loại tin tức</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Check</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Action</th>
                                            
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $categories_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="checkbox" name="check[]" value="<?php echo e($item->id); ?>"></td>
                                        <td><?php echo e($item->name); ?></td>
                                       
                                        
                                      
                                         <td colspan="">
                                            <a href="<?php echo e(url('admin/categories_news/capnhat/'.$item->id)); ?>" class="btn btn-primary">Sửa</a>
                                            <a href="<?php echo e(url('admin/categories_news/xoa/'.$item->id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa không?')" class="btn btn-danger">Xóa</a>
                                             
                                        </td>
                                        
                                      
                                    </tr>
                                    <tr>
                                       
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                     

                                 <tfoot>
                                    <tr>
                                     
                                     
                                        <td>
                                           
                                     <div class="pagination">
    <?php if($categories_news->currentPage() > 0): ?>
        <a href="<?php echo e($categories_news->previousPageUrl()); ?>">Previous</a>
    <?php endif; ?>

    <?php for($i = 1; $i <= $categories_news->lastPage(); $i++): ?>
        <a href="<?php echo e($categories_news->url($i)); ?>" 
           class="<?php echo e(($categories_news->currentPage() == $i) ? ' active' : ''); ?>">
           <?php echo e($i); ?>

        </a>
    <?php endfor; ?>

    <?php if($categories_news->hasMorePages()): ?>
        <a href="<?php echo e($categories_news->nextPageUrl()); ?>">Next</a>
    <?php endif; ?>
</div>
                                          
                                        </td>
                                        <td>
                                           
                                    

                                            <a href="<?php echo e(url('admin/categories_news/them')); ?>" class="btn btn-primary">Thêm</a>
                                                  
                                            <a href="<?php echo e(url('admin/categories_news/thung-rac')); ?>" class="btn btn-primary">Thùng rác
                                                <?php
                                                $count = DB::table('categories_news')->where('deleted_at','!=',null)->count();
                                                ?>
                                                (<?php echo e($count); ?>)
                                                
                                            </a>
                                                <button type="submit" class="btn btn-danger">Xóa nhiều</button>
                                              
                                        </td>
                                    </tr>
                                 </tfoot>
                                </table>
                                
                            </div>
                        </div>
                    </div>
            
                </div>


</form>

<?php $__env->stopSection(); ?>

</form>

<?php echo $__env->make('admin.appLayout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/admin/categories_news/index.blade.php ENDPATH**/ ?>