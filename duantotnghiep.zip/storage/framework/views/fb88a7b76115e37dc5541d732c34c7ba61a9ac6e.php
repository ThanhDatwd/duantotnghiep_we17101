<link rel="stylesheet" href="<?php echo e(asset('css/client/component/productCard.css')); ?>">
<a href="<?php echo e($link); ?>" class="products-card <?php echo e($isRow==true?'isRow':''); ?>">
    <div class="thumb">
        <img src=<?php echo e(asset('upload/'.$thumb)); ?> alt="">
        <i class='bx bx-basket bx-tada'></i>
        <div class="discount <?php echo e($discount>0?'isActive':''); ?>" ><?php echo e($discount); ?>%</div>
    </div>
    <div class="content">
        <div class="progress progress__area <?php echo e($isProgress==true?'isActive':''); ?>" >
               <div class="title"><?php echo e($progressTxt); ?></div>
                <img  class="icon" src="https://bizweb.dktcdn.net/100/434/011/themes/845632/assets/hot-sale.png?1669280565026" alt="">
               <div class="progress-bar progess_status" style="width:<?php echo e($progressValue."%"); ?>" role="progressbar"  aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <h3 class="title"><?php echo e($name??null); ?></h3>
        <div class="price">
            <span class="price_new"><?php echo e($priceCurrent); ?> vnđ</span>
            <del class="price_old"><?php echo e($priceOld); ?> vnđ</del>
        </div>
    </div>
</a>
<?php /**PATH D:\LARAVEL_CƠ BẢN\duantotnghiep\resources\views/components/product-card.blade.php ENDPATH**/ ?>