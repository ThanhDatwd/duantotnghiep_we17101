<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class purchase_histories_detail extends Model
{   
    use HasFactory;
    protected $table = "purchase_history_details";
}
